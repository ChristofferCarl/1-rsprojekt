import sqlite3
from flask import Flask, render_template, session, redirect, url_for, request
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'det-hemmelige-kode-ord' 
app.permanent_session_lifetime = timedelta(minutes=10)

def get_db_connection():
    conn = sqlite3.connect('db/downloads.db')
    conn.row_factory = sqlite3.Row
    return conn

def login_required(f):
    def wrap(*args, **kwargs):
        if not session.get('logged_in'):
            return render_template('login.html'), 403
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

@app.route('/')
def index():
    return redirect(url_for('home'))

@app.route('/removed', methods=['POST'])
def logs_downloads():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO downloads (timestamp, bloatware_removed) VALUES (datetime('now'), 14)")
    conn.commit()
    conn.close()
    return '', 204

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'admin' and password == 'password':
            session['logged_in'] = True
            session.permanent = True
            return redirect(url_for('home'))
        else: 
            return "Forkert brugernavn eller kodeord"
    return render_template('login.html')

@app.route('/home')
@login_required
def home():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(bloatware_removed) FROM downloads")
    total_removed = cursor.fetchone()[0] or 0
    conn.close()
    return render_template('home.html', total_removed=total_removed)

@app.route('/bloatware_removal')
@login_required
def bloatware_removal():
    return render_template('bloatware_removal.html')

@app.route('/præfix1')
@login_required
def præfix1():
    return render_template('præfix1.html')

@app.route('/præfix2')
@login_required
def præfix2():
    return render_template('præfix2.html')

@app.route('/præfix3')
@login_required
def præfix3():
    return render_template('præfix3.html')

@app.route('/bios_opdatering')
@login_required
def bios_opdatering():
    return render_template('bios_opdatering.html')

@app.route('/about')
@login_required
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)