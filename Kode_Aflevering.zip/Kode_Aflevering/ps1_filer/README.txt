Hej Kevin eller andre undervisere der kigger med. :) 

Bare for en sikkerhedsskyld så husk IKKE bare at dobbeltklikke på start.bat. 
Ellers mister du et hav af programmer. :)
Bare højreklik på alle de filer du vil åbne og brug dit yndlings notesprogram. 

God læsning! 