Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

$appsToRemove = @(
    "Microsoft.ZuneMusic",
    "Microsoft.XboxIdentityProvider",
    "Microsoft.BingWeather",
    "Microsoft.YourPhone",
    "Microsoft.XboxSpeechToTextOverlay",
    "Microsoft.XboxGamingOverlay",
    "Microsoft.Xbox.TCUI",
    "Microsoft.WindowsSoundRecorder",
    "Microsoft.WindowsFeedbackHub",
    "Microsoft.MicrosoftSolitaireCollection",
    "Microsoft.GamingApp",
    "Microsoft.BingSearch",
    "Microsoft.BingNews",
    "Clipchamp.Clipchamp",
    "Microsoft.Paint",
    "Microsoft.Todos"
)

foreach ($app in $appsToRemove) {
    Get-AppxPackage -Name $app | Remove-AppxPackage
}

Set-ExecutionPolicy Restricted -Scope CurrentUser -Force