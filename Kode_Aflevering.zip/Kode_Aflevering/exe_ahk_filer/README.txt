Hej Kevin eller andre undervisere der kigger med. :) 

Bare for en sikkerhedsskyld så husk IKKE bare at dobbeltklikke på nogle af de 2 filer.
Ellers åbner de og der er mulighed for at mister du et hav af programmer. :)
Man skal selvfølgelig klikke "ja", men stadigvæk. Pas på. :D 
Bare højreklik på alle de filer du vil åbne og brug dit yndlings notesprogram. 

God læsning! 